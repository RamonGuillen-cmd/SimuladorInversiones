package simuladorinversiones;
/**
 *
 * @author JUGA
 */
import java.util.Scanner;

public class SimuladorInversiones {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        final int NUM_CLIENTES = 5;
        final int MESES = 12;

        // Arreglos unidimensionales
        String[] clientes = new String[NUM_CLIENTES];
        double[] capitalInicial = new double[NUM_CLIENTES];
        double[] tasaMensual = new double[NUM_CLIENTES];

        // Arreglo bidimensional para almacenar saldos
        double[][] saldos = new double[NUM_CLIENTES][MESES];

        System.out.println("========================================");
        System.out.println(" SIMULADOR DE INVERSIONES INVESTPRO");
        System.out.println("========================================");

        // Paso 1. Captura de datos
        for (int i = 0; i < NUM_CLIENTES; i++) {

            System.out.println("\nCliente " + (i + 1));

            System.out.print("Nombre: ");
            clientes[i] = entrada.nextLine();

            System.out.print("Capital inicial ($): ");
            capitalInicial[i] = entrada.nextDouble();

            System.out.print("Tasa mensual (%): ");
            tasaMensual[i] = entrada.nextDouble();

            entrada.nextLine();

            saldos[i][0] = capitalInicial[i];
        }

        // Mostrar asignación de datos
        System.out.println("\n===== DATOS REGISTRADOS =====");

        for (int i = 0; i < NUM_CLIENTES; i++) {
            System.out.println(
                    clientes[i]
                    + " | Capital: $" + capitalInicial[i]
                    + " | Tasa: " + tasaMensual[i] + "%"
            );
        }

        // Paso 2. Proyección a 12 meses
        System.out.println("\n===== PROYECCION A 12 MESES =====");

        for (int i = 0; i < NUM_CLIENTES; i++) {

            System.out.println("\nCliente: " + clientes[i]);

            for (int j = 1; j < MESES; j++) {

                saldos[i][j] = saldos[i][j - 1]
                        * (1 + (tasaMensual[i] / 100));

                System.out.printf(
                        "Mes %d -> $%.2f%n",
                        (j + 1),
                        saldos[i][j]
                );
            }

            System.out.printf(
                    "Saldo final: $%.2f%n",
                    saldos[i][MESES - 1]
            );
        }

        // Paso 3. Consultar proyección de un cliente
        System.out.println("\n===== CONSULTA DE UN CLIENTE =====");

        System.out.print("Ingrese el nombre del cliente: ");
        String consulta = entrada.nextLine();

        boolean encontrado = false;

        for (int i = 0; i < NUM_CLIENTES; i++) {

            if (clientes[i].equalsIgnoreCase(consulta)) {

                encontrado = true;

                System.out.println("\nHistorial de saldos de "
                        + clientes[i]);

                for (int j = 0; j < MESES; j++) {
                    System.out.printf(
                            "Mes %d: $%.2f%n",
                            (j + 1),
                            saldos[i][j]
                    );
                }
            }
        }

        if (!encontrado) {
            System.out.println("Cliente no encontrado.");
        }

        // Paso 4. Búsqueda de otro cliente
        System.out.println("\n===== BUSQUEDA DE CLIENTE =====");

        System.out.print("Ingrese nombre a buscar: ");
        String buscar = entrada.nextLine();

        int posicion = -1;

        for (int i = 0; i < NUM_CLIENTES; i++) {

            if (clientes[i].equalsIgnoreCase(buscar)) {
                posicion = i;
                break;
            }
        }

        if (posicion != -1) {

            System.out.println("\nCliente encontrado.");

            System.out.println("Nombre: "
                    + clientes[posicion]);

            System.out.println("Capital Inicial: $"
                    + capitalInicial[posicion]);

            System.out.println("Tasa Mensual: "
                    + tasaMensual[posicion] + "%");

            System.out.printf(
                    "Saldo al mes 12: $%.2f%n",
                    saldos[posicion][MESES - 1]
            );

        } else {

            System.out.println("Cliente no encontrado.");

        }

        entrada.close();
    }
}
